package com.devops247;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevOps247Application {
    public static void main(String[] args) {
        SpringApplication.run(DevOps247Application.class, args);
    }
}
