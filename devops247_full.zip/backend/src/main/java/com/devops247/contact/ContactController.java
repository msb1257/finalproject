package com.devops247.contact;

import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class ContactController {

    private static final Logger log = LoggerFactory.getLogger(ContactController.class);

    @GetMapping("/health")
    public String health() {
        return "OK";
    }

    @PostMapping("/contact")
    public ResponseEntity<String> submit(@Valid @RequestBody ContactRequest req) {
        log.info("New contact: {} <{}> : {}", req.getName(), req.getEmail(), req.getMessage());
        return ResponseEntity.ok("Message received!");
    }
}
