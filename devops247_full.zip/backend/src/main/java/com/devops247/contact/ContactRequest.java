package com.devops247.contact;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class ContactRequest {

    @NotBlank @Size(max = 100)
    private String name;

    @NotBlank @Email @Size(max = 150)
    private String email;

    @NotBlank @Size(max = 1000)
    private String message;

    public ContactRequest() {}

    public ContactRequest(String name, String email, String message) {
        this.name = name; this.email = email; this.message = message;
    }

    public String getName() { return name; }
    public void setName(String n) { this.name = n; }

    public String getEmail() { return email; }
    public void setEmail(String e) { this.email = e; }

    public String getMessage() { return message; }
    public void setMessage(String m) { this.message = m; }
}
